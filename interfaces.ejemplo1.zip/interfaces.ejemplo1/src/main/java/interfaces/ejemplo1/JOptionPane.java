package interfaces.ejemplo1;


public class JOptionPane {
	public static void main(String[] args) {
		
		String nombre = "Alejandro";
		System.out.println(nombre);
		
	}

}
